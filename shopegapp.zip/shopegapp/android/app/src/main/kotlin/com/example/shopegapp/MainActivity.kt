package com.example.shopegapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
