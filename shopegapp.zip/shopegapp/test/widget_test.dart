// test/widget_test.dart

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:shopegapp/main.dart';

void main() {
  testWidgets('Splash screen shows "Shop EG" title', (WidgetTester tester) async {
    // Build the app
    await tester.pumpWidget(const ShopEgApp());

    // Let the initial frame settle
    await tester.pump();

    // Verify that the splash screen text is present
    expect(find.text('Shop EG'), findsOneWidget);
  });
}
