import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../main.dart';
import 'conditional_accept_screen.dart';

class MerchantOrderDetailsScreen extends StatelessWidget {
  static const String routeName = '/merchant_order_details';

  const MerchantOrderDetailsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ShopEgApp.whiteColor,
      appBar: AppBar(
        title: const Text(
          'Merchant Order Details',
          style: TextStyle(fontFamily: 'Cairo'),
        ),
        backgroundColor: ShopEgApp.redColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            Expanded(
              child: Center(
                child: Text(
                  'Order #12345\nCustomer: Ahmed\nTotal: \$50.00',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 20,
                    color: ShopEgApp.blackColor,
                  ),
                )
                    .animate()
                    .fadeIn(duration: 800.ms),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                // Reject button (red)
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: ShopEgApp.redColor,
                    elevation: 8,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    textStyle: const TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text(
                    'Reject',
                    style: TextStyle(fontFamily: 'Cairo'),
                  ),
                ),

                // Accept button (green)
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    elevation: 8,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    textStyle: const TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text(
                    'Accept',
                    style: TextStyle(fontFamily: 'Cairo'),
                  ),
                ),

                // Conditional Accept button (gold)
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: ShopEgApp.goldColor,
                    elevation: 8,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    textStyle: const TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  onPressed: () =>
                      Navigator.of(context).pushNamed(ConditionalAcceptScreen.routeName),
                  child: const Text(
                    'Conditional',
                    style: TextStyle(fontFamily: 'Cairo'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
