import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../main.dart';
import 'login_screen.dart';

class LanguageSelectionScreen extends StatelessWidget {
  static const String routeName = '/language_selection';

  const LanguageSelectionScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ShopEgApp.whiteColor,
      appBar: AppBar(
        title: const Text('Select Language', style: TextStyle(fontFamily: 'Cairo')),
        backgroundColor: ShopEgApp.redColor,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: ShopEgApp.goldColor,
                elevation: 8,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                textStyle: const TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
              onPressed: () {
                // set locale to Arabic...
                Navigator.of(context).pushNamed(LoginScreen.routeName);
              },
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                child: Text('العربية', style: TextStyle(fontFamily: 'Cairo')),
              ),
            )
                .animate()
                .fadeIn(duration: 800.ms)
                .slideX(begin: -0.5, duration: 800.ms),
            const SizedBox(height: 24),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: ShopEgApp.goldColor,
                elevation: 8,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                textStyle: const TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
              onPressed: () {
                // set locale to English...
                Navigator.of(context).pushNamed(LoginScreen.routeName);
              },
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                child: Text('English', style: TextStyle(fontFamily: 'Cairo')),
              ),
            )
                .animate()
                .fadeIn(duration: 800.ms)
                .slideX(begin: 0.5, duration: 800.ms),
          ],
        ),
      ),
    );
  }
}
