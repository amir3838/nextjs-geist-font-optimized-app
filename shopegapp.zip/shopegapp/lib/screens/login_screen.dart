import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../main.dart';
import 'login_verification_screen.dart';
import 'create_account_screen.dart';

class LoginScreen extends StatefulWidget {
  static const String routeName = '/login';

  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  String _phoneNumber = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ShopEgApp.whiteColor,
      appBar: AppBar(
        title: const Text('Login', style: TextStyle(fontFamily: 'Cairo')),
        backgroundColor: ShopEgApp.redColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              // Phone input
              TextFormField(
                decoration: InputDecoration(
                  labelText: 'Phone Number',
                  labelStyle: const TextStyle(fontFamily: 'Cairo'),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: ShopEgApp.goldColor, width: 2),
                  ),
                  filled: true,
                  fillColor: ShopEgApp.whiteColor,
                ),
                keyboardType: TextInputType.phone,
                style: const TextStyle(fontFamily: 'Cairo'),
                validator: (v) => (v == null || v.isEmpty) ? 'Please enter your phone' : null,
                onSaved: (v) => _phoneNumber = v ?? '',
              )
                  .animate()
                  .fadeIn(duration: 800.ms)
                  .slideY(begin: 0.5, duration: 800.ms),
              const SizedBox(height: 24),

              // Login button
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: ShopEgApp.goldColor,
                  elevation: 8,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  textStyle: const TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                onPressed: () {
                  if (_formKey.currentState?.validate() ?? false) {
                    _formKey.currentState?.save();
                    Navigator.of(context)
                        .pushNamed(LoginVerificationScreen.routeName);
                  }
                },
                child: const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  child: Text('Login', style: TextStyle(fontFamily: 'Cairo')),
                ),
              )
                  .animate()
                  .fadeIn(duration: 1000.ms)
                  .slideY(begin: 0.5, duration: 1000.ms),
              const SizedBox(height: 16),

              // Create account link
              TextButton(
                onPressed: () {
                  Navigator.of(context)
                      .pushNamed(CreateAccountScreen.routeName);
                },
                child: const Text(
                  'Create Account',
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 16,
                    color: ShopEgApp.redColor,
                    decoration: TextDecoration.underline,
                  ),
                ),
              )
                  .animate()
                  .fadeIn(duration: 1000.ms),
            ],
          ),
        ),
      ),
    );
  }
}
