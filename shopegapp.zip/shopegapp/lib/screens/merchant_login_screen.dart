import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../main.dart';
import 'merchant_dashboard_screen.dart';

class MerchantLoginScreen extends StatefulWidget {
  static const String routeName = '/merchant_login';

  const MerchantLoginScreen({Key? key}) : super(key: key);

  @override
  State<MerchantLoginScreen> createState() => _MerchantLoginScreenState();
}

class _MerchantLoginScreenState extends State<MerchantLoginScreen> {
  final _formKey = GlobalKey<FormState>();
  String _username = '', _password = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ShopEgApp.whiteColor,
      appBar: AppBar(
        title: const Text('Merchant Login',
            style: TextStyle(fontFamily: 'Cairo')),
        backgroundColor: ShopEgApp.redColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              // Username field
              TextFormField(
                decoration: InputDecoration(
                  labelText: 'Username',
                  labelStyle: const TextStyle(fontFamily: 'Cairo'),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide:
                    BorderSide(color: ShopEgApp.goldColor, width: 2),
                  ),
                  filled: true,
                  fillColor: ShopEgApp.whiteColor,
                ),
                style: const TextStyle(fontFamily: 'Cairo'),
                validator: (v) =>
                (v == null || v.isEmpty) ? 'Enter username' : null,
                onSaved: (v) => _username = v ?? '',
              )
                  .animate()
                  .fadeIn(duration: 800.ms)
                  .slideY(begin: 0.5, duration: 800.ms),
              const SizedBox(height: 24),
              // Password field
              TextFormField(
                decoration: InputDecoration(
                  labelText: 'Password',
                  labelStyle: const TextStyle(fontFamily: 'Cairo'),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide:
                    BorderSide(color: ShopEgApp.goldColor, width: 2),
                  ),
                  filled: true,
                  fillColor: ShopEgApp.whiteColor,
                ),
                obscureText: true,
                style: const TextStyle(fontFamily: 'Cairo'),
                validator: (v) =>
                (v == null || v.isEmpty) ? 'Enter password' : null,
                onSaved: (v) => _password = v ?? '',
              )
                  .animate()
                  .fadeIn(duration: 900.ms)
                  .slideY(begin: 0.5, duration: 900.ms),
              const SizedBox(height: 24),
              // Login button
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: ShopEgApp.goldColor,
                  elevation: 8,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  textStyle: const TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                onPressed: () {
                  if (_formKey.currentState?.validate() ?? false) {
                    _formKey.currentState!.save();
                    Navigator.of(context)
                        .pushReplacementNamed(MerchantDashboardScreen.routeName);
                  }
                },
                child: const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  child: Text('Login', style: TextStyle(fontFamily: 'Cairo')),
                ),
              )
                  .animate()
                  .fadeIn(duration: 1000.ms),
            ],
          ),
        ),
      ),
    );
  }
}
