import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../main.dart';
import 'main_dashboard_screen.dart';

class LocationPermissionScreen extends StatelessWidget {
  static const String routeName = '/location_permission';

  const LocationPermissionScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ShopEgApp.whiteColor,
      appBar: AppBar(
        title: const Text('Location Permission', style: TextStyle(fontFamily: 'Cairo')),
        backgroundColor: ShopEgApp.redColor,
      ),
      body: Center(
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: ShopEgApp.goldColor,
            elevation: 8,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            textStyle: const TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          onPressed: () {
            Navigator.of(context).pushReplacementNamed(MainDashboardScreen.routeName);
          },
          child: const Padding(
            padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            child: Text('Allow Location Access'),
          ),
        )
            .animate()
            .fadeIn(duration: 1000.ms),
      ),
    );
  }
}
