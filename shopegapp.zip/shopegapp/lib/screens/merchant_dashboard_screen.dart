import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../main.dart';
import 'merchant_login_screen.dart';

class MerchantDashboardScreen extends StatelessWidget {
  static const String routeName = '/merchant_dashboard';

  const MerchantDashboardScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ShopEgApp.whiteColor,
      appBar: AppBar(
        title: const Text('Merchant Dashboard',
            style: TextStyle(fontFamily: 'Cairo')),
        backgroundColor: ShopEgApp.redColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: ListView(
          children: [
            _button(context, 'Incoming Orders', '/merchant/incoming_orders'),
            const SizedBox(height: 16),
            _button(context, 'Accepted Orders', '/merchant/accepted_orders'),
            const SizedBox(height: 16),
            _button(context, 'Completed Orders', '/merchant/completed_orders'),
            const SizedBox(height: 16),
            _button(context, 'Settings', '/merchant/settings'),
          ],
        ),
      ),
    );
  }

  Widget _button(BuildContext ctx, String label, String route) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: ShopEgApp.goldColor,
        elevation: 8,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        textStyle: const TextStyle(
          fontFamily: 'Cairo',
          fontWeight: FontWeight.bold,
          fontSize: 18,
        ),
      ),
      onPressed: () => Navigator.of(ctx).pushNamed(route),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16),
        child: Text(label, style: const TextStyle(fontFamily: 'Cairo')),
      ),
    ).animate().fadeIn(duration: 800.ms);
  }
}
