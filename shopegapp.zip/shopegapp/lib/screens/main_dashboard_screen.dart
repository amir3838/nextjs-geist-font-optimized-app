import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../main.dart';
import 'pharmacy_products_screen.dart';
import 'supermarket_products_screen.dart';
import 'restaurant_products_screen.dart';
import 'cart_screen.dart';
import 'my_orders_screen.dart';
import 'settings_screen.dart';

class MainDashboardScreen extends StatelessWidget {
  static const String routeName = '/main_dashboard';

  const MainDashboardScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ShopEgApp.whiteColor,
      appBar: AppBar(
        title: const Text('Main Dashboard', style: TextStyle(fontFamily: 'Cairo')),
        backgroundColor: ShopEgApp.redColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: ListView(
          children: [
            _buildNavButton(
              context,
              label: '🏥 Pharmacy Products',
              onTap: () => Navigator.of(context)
                  .pushNamed(PharmacyProductsScreen.routeName),
            ),
            const SizedBox(height: 16),
            _buildNavButton(
              context,
              label: '🛒 Supermarket Products',
              onTap: () => Navigator.of(context)
                  .pushNamed(SupermarketProductsScreen.routeName),
            ),
            const SizedBox(height: 16),
            _buildNavButton(
              context,
              label: '🍽️ Restaurant Products',
              onTap: () => Navigator.of(context)
                  .pushNamed(RestaurantProductsScreen.routeName),
            ),
            const SizedBox(height: 16),
            _buildNavButton(
              context,
              label: '🛒 Cart',
              onTap: () =>
                  Navigator.of(context).pushNamed(CartScreen.routeName),
            ),
            const SizedBox(height: 16),
            _buildNavButton(
              context,
              label: '📋 My Orders',
              onTap: () =>
                  Navigator.of(context).pushNamed(MyOrdersScreen.routeName),
            ),
            const SizedBox(height: 16),
            _buildNavButton(
              context,
              label: '⚙️ Settings',
              onTap: () =>
                  Navigator.of(context).pushNamed(SettingsScreen.routeName),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNavButton(BuildContext ctx,
      {required String label, required VoidCallback onTap}) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: ShopEgApp.goldColor,
        elevation: 8,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        textStyle: const TextStyle(
          fontFamily: 'Cairo',
          fontWeight: FontWeight.bold,
          fontSize: 18,
        ),
      ),
      onPressed: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 16),
        child: Text(label, style: const TextStyle(fontFamily: 'Cairo')),
      ),
    ).animate().fadeIn(duration: 800.ms);
  }
}
