import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../main.dart';

class ConditionalAcceptScreen extends StatelessWidget {
  static const String routeName = '/conditional_accept';

  const ConditionalAcceptScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ShopEgApp.whiteColor,
      appBar: AppBar(
        title: const Text('Conditional Accept'),
        backgroundColor: ShopEgApp.redColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            // WhatsApp Chat Button
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: ShopEgApp.goldColor,
                elevation: 8,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                textStyle: const TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
                // shadowColor: ShopEgApp.goldColor.withOpacity(0.7), // optional
              ),
              onPressed: () {
                // TODO: implement WhatsApp chat launch
              },
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                child: Text('WhatsApp Chat'),
              ),
            )
                .animate()
                .fadeIn(duration: 800.ms),
            const SizedBox(height: 24),
            // Phone Call Button
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: ShopEgApp.goldColor,
                elevation: 8,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                textStyle: const TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
                // shadowColor: ShopEgApp.goldColor.withOpacity(0.7), // optional
              ),
              onPressed: () {
                // TODO: implement phone call logic
              },
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                child: Text('Phone Call'),
              ),
            )
                .animate()
                .fadeIn(duration: 800.ms),
          ],
        ),
      ),
    );
  }
}
